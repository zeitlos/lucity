# shop

This is a self-contained export of your Lucity project. It is a standard Helm chart plus one values file per environment, with no dependency on the Lucity control plane.

## Layout

```
chart/      the lucity-app Helm chart
values/     one values file per environment
build.sh    rebuilds the images of services built from source
```

## Deploy an environment

Before the first install, read <https://lucity.cloud/docs/eject#installing-on-your-own-cluster>. It covers what your cluster needs, which values to change, and how to move your data.

Each environment is a separate Helm release in its own namespace. The release must be named `lucity-app`, because the values refer to resources by names derived from it. Install one with:

```sh
helm upgrade --install lucity-app ./chart \
  -f values/development.yaml \
  --namespace shop-development --create-namespace
```

Environments in this export:

- `development`
- `production`

## What you need to provide

The values reflect exactly what ran on Lucity, so they reference infrastructure the platform provided for you. On your own cluster you supply the equivalents:

- **Container images**: services built from source point at Lucity's internal registry, which your cluster cannot reach. Rebuild them with `./build.sh <environment> <registry>`, which builds them the way Lucity does, pushes them to your registry and updates the values to use them.
- **Image pull secret**: if your images are private, create the pull secret referenced under `imagePullSecrets` in your target namespace.
- **Gateway**: HTTP routing expects a Gateway API gateway. Point the `gateway` values at one you run, or remove the routes if you front traffic differently.
- **Databases**: PostgreSQL clusters use the CloudNativePG operator. Install it before deploying, or adjust the database values to match your setup.
- **Buckets**: services that use a bucket read its credentials from a secret named `lucity-bucket-<bucket>`. Create it in your target namespace.

Databases, key-value stores and volumes start out empty. Your project keeps running on Lucity. This export is a copy, not a migration.
